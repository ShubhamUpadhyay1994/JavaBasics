package tutorialspoint;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.sourceforge.htmlunit.corejs.javascript.ast.ExpressionStatement;

public class TutorialsPointPage {

	static WebDriver driver;
	static String parentWindow;

	public static void launchBrowser(String appURL) throws Exception {

		System.setProperty("webdriver.chrome.driver", "C://Automation/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(appURL);
		driver.manage().window().maximize();
	}

	public static void waitForTutorialsPointPage() throws Exception {

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a[href='/articles/index.php']")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("liTL")));
	}

	public static void enterTextIntoSearchBox(String searchText) throws Exception {

		WebElement element = driver.findElement(By.cssSelector("input[class='form-controls search']"));
		element.sendKeys(searchText);
		  parentWindow = driver.getWindowHandle();
		driver.findElement(By.cssSelector("button[class='search-butn']")).click();

//	Set <String>child_window =driver.getWindowHandles();
	
		for (String handle1 : driver.getWindowHandles()) {

			System.out.println(handle1);

			driver.switchTo().window(handle1);

		}

	}

	public static void waitForChildWindow() throws Exception {
		WebElement element = driver.findElement(By.id("lst-ib"));
		driver.findElement(By.linkText("Java Tutorial")).click();
		;
	}

	public static void verifyJavaTutorials() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("/html/body/div[3]/div[1]/div/div[2]/div[1]/div/h1[1]")));
		driver.findElement(By.partialLinkText("Java - Loop Control")).click();
		//driver.switchTo().window(parentWindow);
		//driver.findElement(By.cssSelector("button[class='search-butn']"));
		
//		driver.close();
		driver.quit();
	}
	

}
