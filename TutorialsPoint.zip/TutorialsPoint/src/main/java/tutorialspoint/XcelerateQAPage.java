package tutorialspoint;

import static org.testng.Assert.expectThrows;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class XcelerateQAPage {

	static WebDriver driver;
	static WebElement username1, password1, login, reportCenter, reportsTab, reportTabClose, analysis,
			reportCenterAnalysis;
	static WebDriverWait wait;

	public static void launchBrowser(String appurl) throws Exception {

		System.setProperty("webdriver.chrome.driver", "C://Automation/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(appurl);
		driver.manage().window().maximize();
	}

	public static void waitForXcelerateQAPage() {
		wait = new WebDriverWait(driver, 60);
		WebElement element = driver.findElement(By.id("loginForm"));
		wait.until(ExpectedConditions.visibilityOf(element));
		username1 = driver.findElement(By.id("username"));
		wait.until(ExpectedConditions.visibilityOf(username1));
		password1 = driver.findElement(By.id("password"));
		wait.until(ExpectedConditions.visibilityOf(password1));
		login = driver.findElement(By.id("signinBtn"));
		wait.until(ExpectedConditions.visibilityOf(login));

	}

	public static void enterCredentials(String username, String password) {
		username1.sendKeys(username);
		password1.sendKeys(password);
		login.click();

	}

	public static void waitForHomePage() {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("logoImageHomeBg")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("inputMenuClientNumSearch")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("inputMenuSearch")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("flagVal")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("reportPopoverTab")));
	/*	reportCenter = driver.findElement(By.className("reportTabContainerLeft"));
		wait.until(ExpectedConditions.visibilityOf(reportCenter));
		reportsTab = driver.findElement(By.id("reportCenterReportsTab"));
		wait.until(ExpectedConditions.visibilityOf(reportCenter));
		reportTabClose = driver.findElement(By.className("navCloseIcon spriteNav"));
		wait.until(ExpectedConditions.visibilityOf(reportTabClose));
		reportTabClose = driver.findElement(By.id("navCloseIcon spriteNav"));
		wait.until(ExpectedConditions.visibilityOf(reportTabClose));*/
		analysis = driver.findElement(By.linkText("Analysis"));
		wait.until(ExpectedConditions.visibilityOf(analysis));
	}

	public static void clickOnAnalysisTab() {
		analysis.click();
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("analysisMenu")));
		reportCenterAnalysis = driver.findElement(By.cssSelector("a[href='#analysisCollapseOne']"));
		wait.until(ExpectedConditions.visibilityOf(reportCenterAnalysis));
		reportCenterAnalysis.click();
	}
	
	public static void clickOnReportCenter(String selectText,String reportName){
		driver.findElement(By.linkText("Generate Reports")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mainContentWrapper")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("report-category")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("report-category-select")));
		
		Select dropdown = new Select(driver.findElement(By.id("report-category-select")));
		dropdown.selectByVisibleText(selectText);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("report-name")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("report-name-select"))); 
	
		Select reportName1 = new Select(driver.findElement(By.id("report-name-select")));
		reportName1.selectByVisibleText(reportName);
		
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("client-filters")));

		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("client-filters-box")));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("client-number-tab text-tab text-tab-wave-3 active")));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("remove-client-icon"))).click(); 
	

		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("vertical-center")));
		
	}

}
