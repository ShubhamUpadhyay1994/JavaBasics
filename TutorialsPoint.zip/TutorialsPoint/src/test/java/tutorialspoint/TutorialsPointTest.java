package tutorialspoint;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import tutorialspoint.TutorialsPointPage;

public class TutorialsPointTest {

	@Test(alwaysRun =true)
	@Parameters("appUrl")
	public static void launchBrowser(String appURL) throws Exception{
		TutorialsPointPage.launchBrowser(appURL);
		
	}
	
	@Test(dependsOnMethods ="launchBrowser")
	public static void waitForTutorialsPointPage() throws Exception{
	TutorialsPointPage.waitForTutorialsPointPage();
	}
	
	@Test(dependsOnMethods ="waitForTutorialsPointPage")
	@Parameters("searchText")
	public static void enterTextIntoSearchBox(String searchText) throws Exception{
		TutorialsPointPage.enterTextIntoSearchBox(searchText);
	}
	@Test(dependsOnMethods ="enterTextIntoSearchBox")
	public static void waitForChildWindow() throws Exception{
		TutorialsPointPage.waitForChildWindow();
		TutorialsPointPage.verifyJavaTutorials();
		//TutorialsPointPage.closeParentWindow();
		
}
}
