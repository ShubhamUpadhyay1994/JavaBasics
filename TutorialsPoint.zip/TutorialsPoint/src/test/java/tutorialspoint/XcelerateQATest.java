package tutorialspoint;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class XcelerateQATest {

	@Test(alwaysRun=true)
	@Parameters("appurl")
	public static void testLaunchBrowser(String appurl) throws Exception{
		XcelerateQAPage.launchBrowser(appurl);
	}
	
	@Test(dependsOnMethods="testLaunchBrowser")
	@Parameters({"username","password"})
	public static void testWaitForXcelerateQALoginPage(String username,String password) throws Exception{
		XcelerateQAPage.waitForXcelerateQAPage();
		XcelerateQAPage.enterCredentials(username, password);
	}
	@Test(dependsOnMethods="testWaitForXcelerateQALoginPage")
	public static void testWaitForHomePage(){
		XcelerateQAPage.waitForHomePage();
	}
	@Test(dependsOnMethods="testWaitForHomePage")
	public static void testClickOnAnalysisTab(){
		XcelerateQAPage.clickOnAnalysisTab();
		
	}
	@Test(dependsOnMethods="testClickOnAnalysisTab")
	@Parameters({"selectText","reportName"})
	public static void testwaitForReportCenetrPage(String selectText,String reportName){
		XcelerateQAPage.clickOnReportCenter(selectText,reportName);
	}
}
