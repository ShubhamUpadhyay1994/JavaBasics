package com.element.test.Sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class W3SchoolPage {
	
	static WebDriver driver;
	
	public static void launchChrome(String appUrl) throws Exception
	{
		System.out.println("launching Firefox browser");
		
	    System.setProperty("webdriver.chrome.driver","C://Automation/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(appUrl);
	}

 public static void EnterText(String searchText) throws Exception{
	 
	 WebDriverWait wait = new WebDriverWait(driver,20);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("lst-ib")));
	 
	 WebElement Searchbox = driver.findElement(By.id("lst-ib"));
	 Searchbox.sendKeys(searchText);
	 //WebDriverWait wait = new WebDriverWait(driver,50); 
	 
	 WebDriverWait wait1 = new WebDriverWait(driver,30);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class='sbsb_a']")));
	 
	// driver.close();
	 
	 /*WebElement searchButton = driver.findElement(By.cssSelector("input[value='Google Search']"));
	 searchButton.click();*/
	
	 
 }
 
 
	
}
