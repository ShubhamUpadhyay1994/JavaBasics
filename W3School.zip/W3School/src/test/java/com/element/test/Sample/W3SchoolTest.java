package com.element.test.Sample;

import java.lang.annotation.Documented;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class W3SchoolTest {

	public static String FLEET_OFFICE_PASSWORD;

	@Test(alwaysRun = true)
	@Parameters("appUrl")
	public void enterURL(String appUrl) throws Exception {
		W3SchoolPage.launchChrome(appUrl);

	}

	@Test(dependsOnMethods = "enterURL")
	@Parameters("searchText")
	public void entertext(String searchText) throws Exception {
		W3SchoolPage.EnterText(searchText);
	}

}
